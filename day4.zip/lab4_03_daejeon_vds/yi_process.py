import numpy as np
import pandas as pd
from pandas import datetime
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split


def parser(x):
    return datetime.strptime(x, '%Y-%m-%d %H:%M:%S')

def settingXY(test_day, config):
    vdsID = config["vdsID"]
    nMem = config["nMem"]
    nFeature  = config["nFeature"]

    filename = '../dataVDS/{}.csv'.format(vdsID)
    f = pd.read_csv(filename,
        header=0, parse_dates=[0], index_col=0, squeeze=True, date_parser=parser)
    df=pd.DataFrame(f)
    CUT_OFF_NROW = 5964 
    nOut = 6 
    #print('vds_Input:\n',df.head(5))
    print('vds[6252]:\n',df[CUT_OFF_NROW:CUT_OFF_NROW+2])

    df=df.values

    scl = MinMaxScaler()
    scaleVDS = scl.fit_transform(df)

    ## division = len(array) - num_data*nFeature

    print('vds_shape:\n',scaleVDS.shape)
    X_VDS, Y_VDS = processData(scaleVDS, nMem, nFeature)

    print('X_VDS',X_VDS.shape)
    #print('M+F:',nMem+nFeature,'Diff:',scaleVDS.shape[0] - X_VDS.shape[0])

    
    #division = 6252   # 2017.04.23 00:00:00 SUNDAY 
    division = CUT_OFF_NROW   # 2017.04.23 00:00:00 SUNDAY 

    #Off_set = 108 
    #div_data = test_day*288     + Off_set
    #div_end =  (test_day-1)*288 + Off_set
    if test_day == 0:
        Off_set1 = division - nMem
        #Off_set2 = division + 7*288
        Off_set2 = division + 7*288 
    else:     
        Off_set1 = division + (test_day-1)*288  - nMem
        #Off_set2 = division + test_day*288
        Off_set2 = division + test_day*288


    vds_train = scaleVDS[ :division]
    vds_test = scaleVDS[Off_set1: Off_set2]

    x_train, y_train = processData(vds_train,nMem,nFeature)
    y_train = np.array([list(idx.ravel()) for idx in y_train])
    
    x_test, y_test = processData(vds_test,nMem, nFeature, nFeature)
    y_test = np.array([list(idx.ravel()) for idx in y_test])


    print('X_tra',x_train.shape)
    print('X_tes',x_test.shape)
    print('y_tra',y_train.shape)
    print('y_tes',y_test.shape)

    return [x_train, y_train, x_test, y_test, scaleVDS, scl, nOut ]


def processData(data, nMem, nFeature, jump=1):
    X,Y = [],[]
    print('jump=',jump)
    for i in range(0,len(data) -nMem -nFeature +1, jump):
        X.append(data[i:(i+nMem)])
        Y.append(data[(i+nMem):(i+nMem+nFeature)])
    return np.array(X), np.array(Y)

