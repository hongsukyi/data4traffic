import os
import numpy as np
import pandas as pd 
import math
import matplotlib.pyplot as plt

def MakeFileName(config):
    vdsID      = config["vdsID"]
    nMem       = config["nMem"]
    nFeature   = config["nFeature"]
    num_data   = config["num_data"]
    rnn_model  = config["rnn"]
    n          = config["neurons"]

    CKPT_DIR = "./Output/{}_{}_MFDN({},{},{},{})/".format(vdsID,rnn_model,nMem,nFeature,num_data,n)
    if not os.path.exists(CKPT_DIR):
        os.makedirs(CKPT_DIR)
	
    FILENAME = "M{}.F{}".format(nMem,nFeature)
    return CKPT_DIR, FILENAME

def myMAPE(y_true, y_pred):
    y_true = np.ravel(y_true)
    y_pred = np.ravel(y_pred)
    y = [x for x in y_true if x > 0]
    y_pred = [y_pred[i] for i in range(len(y_true)) if y_true[i] > 0]
    num = len(y_pred)
    sums = 0
    for i in range(num):
        tmp = abs(y[i] - y_pred[i]) / y[i]
        sums += tmp
    mape = sums * (100 / num)
    return mape

      
def eva_regress(y_true, y_pred, model,metrics, config,eTime,name,test_day,icount): 
    mape = myMAPE(y_true, y_pred)
    vs = metrics.explained_variance_score(y_true, y_pred)
    mae = metrics.mean_absolute_error(y_true, y_pred)
    mse = metrics.mean_squared_error(y_true, y_pred)
    r2 = metrics.r2_score(y_true, y_pred)
    rmse = math.sqrt(mse)
    print('mse : %8.6f' % mse)
    print('mae : %8.6f' % mae)
    print('mape: %8.6f%%' % mape)
    print('rmse: %8.6f' % rmse)
    print('exvc: %8.6f' % vs)
    print('r2  : %8.6f' % r2)     
    print('Time: %8.6f' % eTime)   
    
    nMem     = config["nMem"]
    nFeature = config["nFeature"]
    num_data = config["num_data"]


    CKPT_DIR, FILENAME = MakeFileName(config)
    fname = CKPT_DIR + 'log_'+"{}".format(nMem)+ '.csv'    
    #fname = CKPT_DIR + 'log.csv'    
    f=open(fname,'a+')
    if icount ==1: 
        f.write('tday, snMem, nFeature, num_data, mse, mae, mape, rmse, vs, r2, eTime\n') 

    f.write('%8d, %8d, %8d, %8d, %8.5f, %8.5f,%8.5f,%8.5f,%8.5f,%8.5f,%8.5f\n'
        % (test_day,nMem, nFeature, num_data, mse, mae, mape, rmse, vs, r2, eTime))
    f.close()


# FIG1 
def drawing_epoch(hist,Loss,config):
    plt.figure(figsize = (12,8))
    plt.rcParams.update({'font.size': 14, 'font.family': 'monospace'  })  #serif, fantasy, cursive
    plt.plot(hist.history['loss'],label='loss')
    plt.plot(hist.history['val_loss'], label='val_loss')
    plt.legend(loc='best')
    plt.ylabel('LOSS')
    plt.xlabel('Epoch')

    CKPT_DIR, FILENAME = MakeFileName(config)
    fname = CKPT_DIR + 'Loss_' + FILENAME+'.jpg'  
    plt.savefig(fname,dpi=600)
    print("Saved model `{}` to disk".format(fname))
    #plt.show()
    plt.close()

    plt.figure(figsize = (12,8))
    plt.rcParams.update({'font.size': 14, 'font.family': 'monospace'  })  #serif, fantasy, cursive
    plt.plot(hist.history['mean_absolute_error'],label='mae')
    plt.plot(hist.history['val_mean_absolute_error'], label='val_mae')
    plt.legend(loc='best')
    plt.ylabel('MAE')
    plt.xlabel('Epoch')

    CKPT_DIR, FILENAME = MakeFileName(config)
    fname = CKPT_DIR + 'MAE_' + FILENAME+'.jpg'  
    plt.savefig(fname,dpi=600)
    print("Saved model `{}` to disk".format(fname))
    #plt.show()
    plt.close()





def do_inv_trans(output_result,nOut,scl):
    #From input/output nootbook: apply makeup, use scl.inv_trans and remove makeup
    
    #transform to input shape
    original_matrix_format = []
    for result in output_result:
        #do inverse transform
        original_matrix_format.append(scl.inverse_transform([result[x:x+nOut] for x in range(0, len(result), nOut)]))
    original_matrix_format = np.array(original_matrix_format)
    
    #restore to original shape
    for i in range(len(original_matrix_format)):
        output_result[i] = original_matrix_format[i].ravel()

    return output_result

def prediction_by_step_by_road(raw_model_output, nOut):
    matrix_prediction = []
    for i in range(0,nOut):
        matrix_prediction.append([[lista[j] for j in range(i,len(lista),nOut)] for lista in raw_model_output])
    return np.array(matrix_prediction)


def target_by_road(raw_model_output, nOut):
    matrix_target = [[] for x in range(nOut)]    
    for output in raw_model_output:
        for i in range (nOut):
            for j in range(0,len(output),nOut):
                matrix_target[i].append(output[i+j])
    return np.array(matrix_target)


def drawing_1day(MP, MT, config,name,test_day, y_pred_all,y_real_all):

    nFeature = config['nFeature']
    #test_day = config['test_day']

    routes = ['TR_VOL', 'SM_TR_VOL', 'MD_TR_VOL', 'LG_TR_VOL', 'TRVL_SPD','OCCUPY_RATE']
    colors = ['r','m','deeppink','orangered','m','r','g','b','r','g','c','m'] #from matplotlib

    #vds_to_show = [0,1,2,3,4,5]
    for idx in range(0,6): 
        plt.figure(figsize = (12,8))
        plt.rcParams.update({'font.size': 14, 'font.family': 'monospace'  })  #serif, fantasy, cursive
        
        if nFeature == 288:
            plt.plot(MP[idx], label='predict_{}'.format(routes[idx]),color=colors[idx])
        else :
            for i in range(0,len(MP[idx])):
                plt.plot([x + i*nFeature for x in range(len(MP[idx][i]))], MP[idx][i], color=colors[idx])
            plt.plot(0,MP[idx][0][0], color=colors[idx], label='predict_{}'.format(routes[idx])) 

        #plt.plot(0,MP[idx][0][0] ,color='gray', label='predict_{}'.format(routes[idx])) 
        plt.plot(MT[idx], label='target_{}'.format(routes[idx]))
        #plt.grid()
        plt.xlim(0,24)
        plt.legend(loc='best')
        plt.ylabel('{}'.format(routes[idx]))
  
 
        if test_day == 0:
            plt.xlabel('Time of the day [{}]'.format(name))    
            plt.xticks([0, 288, 576, 864, 1152, 1440, 1728, 2016],
                [x for  x in ['SUN','MON', 'TUE','WEN','THU','FRI','SAT','SUN']])
        else:
            plt.xlabel('Time of the day [{}]'.format(name))    
            plt.xticks(np.arange(0,289,step=36),[x for  x in [0, 3,6,9,12,15,18,21,24]])

        CKPT_DIR, FILENAME = MakeFileName(config)
        LabelName = "{}_v[{}]_".format(name,idx)
        fname = CKPT_DIR + LabelName + FILENAME+'.jpg'  
        plt.savefig(fname,dpi=600)
        #plt.show()  
        plt.close()
        #print("Saved model `{}` to disk".format(fname))
        #if idx == 0: 
        ##plt.show()  
        #else:    
        #    print('Pass :',idx)
            ##plt.show()  


# ALL Curves in One Graph
    vds_to_show = [0,1,2,3]
    plt.figure(figsize = (12,8))
    plt.rcParams.update({'font.size': 14, 'font.family': 'monospace'  })  #serif, fantasy, cursive
    #colors = ['r','g','c','m','y','k','w','b'] #from matplotlib
    colors = ['r','m','deeppink','c','y','r','w','b'] #from matplotlib
    for idx in vds_to_show:

        if nFeature == 288:
            plt.plot(MP[idx], label='predict_{}'.format(routes[idx]),color=colors[idx])
        else :
            for i in range(0,len(MP[idx])):
                plt.plot([x + i*nFeature for x in range(len(MP[idx][i]))], MP[idx][i], color=colors[idx])
            plt.plot(0,MP[idx][0][0], color=colors[idx], label='predict_{}'.format(routes[idx]))         
    
    #for idx in vds_to_show:
        plt.plot(MT[idx], label='target_{}'.format(routes[idx]))

    plt.legend(loc='best')
    plt.ylabel('{}'.format(routes[0]))
    plt.xlim(0,24)
    #plt.grid()
 
    if test_day == 0:
        plt.xlabel('Time of the day [{}]'.format(name)) 
        plt.xticks([0, 288, 576, 864, 1152, 1440, 1728, 2016],
            [x for  x in ['SUN','MON', 'TUE','WEN','THU','FRI','SAT','SUN']])
    else:
        plt.xlabel('Time of the day [{}]'.format(name))   
        plt.xticks(np.arange(0,289,step=36),[x for  x in [0, 3,6,9,12,15,18,21,24]])

    CKPT_DIR, FILENAME = MakeFileName(config)
    LabelName = "{}_v[{}]_".format(name,9)
    fname = CKPT_DIR + LabelName + FILENAME+'.jpg'  
    plt.savefig(fname,dpi=600)
    
    #plt.show()   

    plt.close()
    #print("Saved model `{}` to disk".format(fname))
  

def drawing_7day(MP, MT, config):

    nFeature = config['nFeature']
    routes = ['TR_VOL', 'SM_TR_VOL', 'MD_TR_VOL', 'LG_TR_VOL', 'TRVL_SPD','OCCUPY_RATE']
    colors = ['r','g','c','m','y','k','w','b','r','g','c','m'] #from matplotlib
    vds_to_show = [0,1,2,3,4,5]
    for idx in vds_to_show:
        plt.figure(figsize = (12,8))
        plt.rcParams.update({'font.size': 14, 'font.family': 'monospace'  })  
        for i in range(0,len(MP[idx])):
            plt.plot([x + i*nFeature for x in range(len(MP[idx][i]))], MP[idx][i], color=colors[idx])
        plt.plot(0,MP[idx][0][0] ,color=colors[idx], label='predict_{}'.format(routes[idx])) 
        #plt.plot(0,MP[idx][0][0] ,label='predict_{}'.format(routes[idx]))
           #only to place the label
        plt.plot(MT[idx], color='gray',label='target_{}'.format(routes[idx]))

        plt.legend(loc='best')
        plt.ylabel('{}'.format(routes[idx]))
        plt.xlabel('Time of the day (5mins)')

    CKPT_DIR, FILENAME = MakeFileName(config)
    LabelName = '7X'+'{}'.format(idx)
    fname = CKPT_DIR + LabelName + FILENAME+'.jpg'  
    plt.savefig(fname,dpi=600)
    #print("Saved model `{}` to disk".format(fname))
    #plt.show()
    plt.close()