# coding: utf-8
import time
import math
import os
import sys
import argparse
import numpy as np

import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import LSTM,Dense,Dropout

from keras.models import load_model
import sklearn.metrics as metrics
from keras.utils.vis_utils import plot_model, model_to_dot

import yi_model, yi_process, yi_util 

vdsID     = 'vds15'    # (35: E->W) (34:W->E) Lotte Department BD


nMem      =  288   # 12 default 

nFeature  =  24    # (1,288) (2,576) (3,864)  
num_data  =  12    # 24개 데이터를 예측 
nb_epoch  =  200   # 10
neurons   =  36 

def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        default="lstm",
        help="Model to train.")
    args = parser.parse_args()
     
    rnn_model = str(args.model)
    print(rnn_model)

    config = {"vdsID": vdsID, "nMem": nMem, "nFeature": nFeature, "num_data" : num_data, 
        "nb_epoch": nb_epoch, "rnn":rnn_model,"neurons":neurons}

    x_train, y_train, x_test,y_test, _, _, nOut = yi_process.settingXY(1, config)
    global_start_time = time.time()
    if args.model == 'lstm':    
        m = yi_model.get_lstm(nOut,config)
        weight = yi_model.train_model(m, x_train, y_train,config)
    if args.model == 'gru':
        m = yi_model.get_gru(nOut,config)
        weight = yi_model.train_model(m, x_train, y_train,config)
    if args.model == 'saes':
        x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1]))
        m = yi_model.get_saes([12, 400, 400, 400, 1])
        train_seas(m, x_train, y_train, args.model, config)

    eTimes=time.time() - global_start_time
    print ('Training duration (s) : ',eTimes)
 
    ickeck = 7
    if ickeck == 1 :
        test_days = [5]
        name_days = ['2017-04-26-WEN']
    elif ickeck ==3 : 
        test_days = [5,2,0]
        name_days = ['2017-04-26-WEN','2017-04-23-SUN','2017-04-22' ]
    elif ickeck ==7 : 
        test_days = [1,2,3,4,5,6,7,0]
        name_days = ['2017-04-23-SUN', '2017-04-24-MON',
            '2017-04-25-TUE', '2017-04-26-WEN','2017-04-27-THU',
            '2017-04-28-FRI','2017-04-29-SAT','2017-04-22']
    else :
        print('Done.. Check ickeck.')   

    predA = []
    realA = []
    icount = 1
    for t, name in zip(test_days, name_days):
        _, _, x_test,y_test, scaleVDS, scl, nOut = yi_process.settingXY(t,config)        
        y_pred = weight.predict(x_test)
        yi_util.eva_regress(y_test, y_pred, weight, metrics, config, eTimes,name,t,icount)
        icount = icount + 1 

        y_pred = yi_util.do_inv_trans(y_pred,nOut,scl)
        y_pred = yi_util.prediction_by_step_by_road(y_pred, nOut)

        y_true = yi_util.do_inv_trans(y_test,nOut,scl)
        y_true = yi_util.target_by_road(y_true, nOut)

        if nFeature == 288 : 
            y_pred = np.array([list(idx.ravel()) for idx in y_pred])
            predA.append(y_pred)
            realA.append(y_true)
            print(y_pred.shape, y_true.shape)
            
        yi_util.drawing_1day(y_pred, y_true, config, name,t,predA,realA)
         
print('Program Test Finished...')

if __name__ == '__main__':
    main(sys.argv)